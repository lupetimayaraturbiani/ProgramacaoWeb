import React, { useState } from 'react';
import './App.css';

const CadastroForm = () => {
    const [formData, setFormData] = useState({
        nome: '',
        email: '',
        senha: '',
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log("Dados enviados: ", formData);
        alert(`Dados Cadastrados!
        Nome: ${formData.nome}
        Email: ${formData.email}
        Senha: ${formData.senha}`);

        setFormData({
            nome: '',
            email: '',
            senha: '',
        });
    };

    return (
        <form className='cadastro-form' onSubmit={handleSubmit}>
            <h2>Cadastro</h2>
            <label>Nome:
                <input type='text' name='nome' value={formData.nome} onChange={handleChange} required></input>
            </label>
            <label>Email:
                <input type='email' name='email' value={formData.email} onChange={handleChange} required></input>
            </label>
            <label>Senha:
                <input type='password' name='senha' value={formData.senha} onChange={handleChange} required></input>
            </label>
            <button type='submit'>Cadastrar</button>
        </form>
    );
};

export default CadastroForm;