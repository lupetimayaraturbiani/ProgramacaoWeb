import React from 'react';
import CadastroForm from './CadastroForm';

function App() {
  return (
    <div className="App">
      <CadastroForm></CadastroForm>
    </div>
  );
}

export default App;
